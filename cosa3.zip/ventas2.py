import tkinter as tk
from datetime import datetime
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP
from tkinter import messagebox, ttk

import mysql.connector

from reportes import generar_reporte_excel, generar_reporte_pdf


PRECIO_POR_KILO = Decimal("21")


def conectar():
    try:
        return mysql.connector.connect(
            host="localhost",
            user="root",
            passwd="",
            database="tortilleria_az",
        )
    except mysql.connector.Error as error:
        messagebox.showerror(
            "Error de conexión",
            f"No fue posible conectar con la base de datos:\n{error}",
        )
        return None


def citar_columna(nombre):
    return f"`{nombre.replace('`', '``')}`"


def cargar_estructura():
    conexion = conectar()
    if conexion is None:
        return False

    cursor = None
    try:
        cursor = conexion.cursor()
        cursor.execute("DESCRIBE ventas")
        for campo in cursor.fetchall():
            columnas.append(
                {
                    "nombre": campo[0],
                    "nulo": campo[2] == "YES",
                    "clave": campo[3],
                    "predeterminado": campo[4],
                    "autoincremental": "auto_increment" in (campo[5] or "").lower(),
                }
            )
        claves_primarias.extend(
            campo["nombre"] for campo in columnas if campo["clave"] == "PRI"
        )
        return bool(columnas)
    except mysql.connector.Error as error:
        messagebox.showerror(
            "Error al cargar ventas",
            f"No fue posible consultar la estructura de la tabla ventas:\n{error}",
        )
        return False
    finally:
        if cursor is not None:
            cursor.close()
        conexion.close()


def limpiar_campos():
    global registro_seleccionado
    registro_seleccionado = None
    for nombre, campo in campos.items():
        if nombre == "precio_total":
            campo.configure(state=tk.NORMAL)
        campo.delete(0, tk.END)
        if nombre == "precio_total":
            campo.configure(state="readonly")
    tabla.selection_remove(tabla.selection())


def validar_valor_numerico(nombre, valor):
    if nombre not in ("kilos", "precio_total"):
        return True, valor

    try:
        numero = Decimal(valor)
    except InvalidOperation:
        messagebox.showwarning(
            "Valor inválido",
            f"El campo {nombre} debe contener un número.",
        )
        return False, None

    if not numero.is_finite() or (
        nombre == "kilos" and numero <= 0
    ) or (
        nombre == "precio_total" and numero < 0
    ):
        requisito = "mayor que cero" if nombre == "kilos" else "cero o mayor"
        messagebox.showwarning(
            "Valor inválido",
            f"El campo {nombre} debe ser un número {requisito}.",
        )
        return False, None

    return True, numero


def validar_fecha(valor):
    try:
        return True, datetime.strptime(valor, "%Y-%m-%d").date()
    except ValueError:
        messagebox.showwarning(
            "Fecha inválida",
            "Ingresa la fecha con formato AAAA-MM-DD, por ejemplo 2026-11-12.",
        )
        return False, None


def validar_valor(nombre, valor):
    if nombre == "fecha":
        return validar_fecha(valor)
    return validar_valor_numerico(nombre, valor)


def calcular_total(kilos):
    try:
        cantidad = Decimal(str(kilos))
        if not cantidad.is_finite() or cantidad <= 0:
            return None
        return (cantidad * PRECIO_POR_KILO).quantize(
            Decimal("0.01"),
            rounding=ROUND_HALF_UP,
        )
    except InvalidOperation:
        return None


def actualizar_precio_total(event=None):
    campo_kilos = campos.get("kilos")
    campo_total = campos.get("precio_total")
    if campo_kilos is None or campo_total is None:
        return

    total = calcular_total(campo_kilos.get().strip())
    campo_total.configure(state=tk.NORMAL)
    campo_total.delete(0, tk.END)
    if total is not None:
        campo_total.insert(0, str(total))
    campo_total.configure(state="readonly")


def formatear_fila(fila):
    valores = list(fila)
    for indice, campo in enumerate(columnas):
        if campo["nombre"] == "fecha" and valores[indice] is not None:
            valor = valores[indice]
            valores[indice] = (
                valor.strftime("%Y-%m-%d")
                if hasattr(valor, "strftime")
                else str(valor)[:10]
            )
    return valores


def mostrar_ventas():
    conexion = conectar()
    if conexion is None:
        return

    cursor = None
    try:
        cursor = conexion.cursor()
        cursor.execute("SELECT * FROM ventas")
        filas = cursor.fetchall()

        identificadores = [f"col_{indice}" for indice in range(len(columnas))]
        tabla.delete(*tabla.get_children())
        tabla.configure(columns=identificadores)

        for identificador, campo in zip(identificadores, columnas):
            tabla.heading(identificador, text=campo["nombre"])
            tabla.column(identificador, width=140, minwidth=80, anchor=tk.W)

        for fila in filas:
            tabla.insert("", tk.END, values=formatear_fila(fila))
        limpiar_campos()
    except mysql.connector.Error as error:
        messagebox.showerror(
            "Error al consultar ventas",
            f"No fue posible mostrar las ventas:\n{error}",
        )
    finally:
        if cursor is not None:
            cursor.close()
        conexion.close()


def buscar_ventas():
    global registro_seleccionado
    filtros = [
        (campo["nombre"], campos[campo["nombre"]].get().strip())
        for campo in columnas
        if campo["nombre"] in campos and campos[campo["nombre"]].get().strip()
    ]

    conexion = conectar()
    if conexion is None:
        return

    cursor = None
    try:
        cursor = conexion.cursor()
        consulta = "SELECT * FROM ventas"
        parametros = []
        if filtros:
            condiciones = []
            for nombre, valor in filtros:
                if nombre in claves_primarias:
                    condiciones.append(f"{citar_columna(nombre)} = %s")
                    parametros.append(valor)
                else:
                    condiciones.append(
                        f"CAST({citar_columna(nombre)} AS CHAR) LIKE %s"
                    )
                    parametros.append(f"%{valor}%")
            consulta += " WHERE " + " AND ".join(condiciones)
        cursor.execute(consulta, tuple(parametros))
        filas = cursor.fetchall()

        tabla.delete(*tabla.get_children())
        for fila in filas:
            tabla.insert("", tk.END, values=formatear_fila(fila))
        tabla.selection_remove(tabla.selection())
        registro_seleccionado = None
        if not filas:
            messagebox.showinfo("Sin resultados", "No se encontraron ventas.")
    except mysql.connector.Error as error:
        messagebox.showerror(
            "Error al buscar ventas",
            f"No fue posible buscar las ventas:\n{error}",
        )
    finally:
        if cursor is not None:
            cursor.close()
        conexion.close()


def leer_valores_insertar():
    valores = {}
    for campo in columnas:
        nombre = campo["nombre"]
        if campo["autoincremental"] or nombre == "precio_total":
            continue
        if nombre not in campos:
            continue
        valor = campos[nombre].get().strip()
        if not valor and (campo["nulo"] or campo["predeterminado"] is not None):
            continue
        if not valor and not campo["nulo"]:
            messagebox.showwarning(
                "Dato faltante",
                f"El campo {nombre} es obligatorio.",
            )
            return None
        valido, valor_convertido = validar_valor(
            nombre,
            valor,
        )
        if not valido:
            return None
        valores[nombre] = valor_convertido if valor else None

    if "precio_total" in campos:
        total = calcular_total(valores.get("kilos"))
        if total is None:
            messagebox.showwarning(
                "Kilos inválidos",
                "Ingresa una cantidad de kilos válida para calcular el precio total.",
            )
            return None
        valores["precio_total"] = total
    return valores


def insertar_venta():
    valores = leer_valores_insertar()
    if valores is None:
        return
    if not valores:
        messagebox.showwarning(
            "Datos faltantes",
            "Ingresa los datos de la venta antes de insertar.",
        )
        return

    nombres = list(valores)
    columnas_sql = ", ".join(citar_columna(nombre) for nombre in nombres)
    marcadores = ", ".join(["%s"] * len(nombres))
    consulta = f"INSERT INTO ventas ({columnas_sql}) VALUES ({marcadores})"

    conexion = conectar()
    if conexion is None:
        return

    cursor = None
    try:
        cursor = conexion.cursor()
        cursor.execute(consulta, tuple(valores.values()))
        conexion.commit()
        messagebox.showinfo("Venta insertada", "La venta se registró correctamente.")
        mostrar_ventas()
    except mysql.connector.Error as error:
        messagebox.showerror(
            "Error al insertar",
            f"No fue posible registrar la venta:\n{error}",
        )
    finally:
        if cursor is not None:
            cursor.close()
        conexion.close()


def obtener_clave_seleccionada():
    if not claves_primarias:
        messagebox.showwarning(
            "Clave primaria requerida",
            "La tabla ventas no tiene clave primaria; no se puede identificar "
            "con seguridad qué registro actualizar o eliminar.",
        )
        return None
    if claves_primarias == ["id"]:
        valor_id = campos["id"].get().strip()
        if not valor_id:
            messagebox.showwarning(
                "ID requerida",
                "Escribe el ID o selecciona una venta de la tabla.",
            )
            return None
        try:
            identificador = int(valor_id)
        except ValueError:
            messagebox.showwarning(
                "ID inválida",
                "El ID debe ser un número entero.",
            )
            return None
        if identificador <= 0:
            messagebox.showwarning(
                "ID inválida",
                "El ID debe ser mayor que cero.",
            )
            return None
        return {"id": identificador}
    if registro_seleccionado is None:
        messagebox.showwarning(
            "Selecciona una venta",
            "Selecciona una venta de la tabla antes de actualizarla o eliminarla.",
        )
        return None
    return registro_seleccionado


def actualizar_venta():
    clave = obtener_clave_seleccionada()
    if clave is None:
        return

    nombres_clave = set(claves_primarias)
    actualizables = [
        campo
        for campo in columnas
        if campo["nombre"] not in nombres_clave and not campo["autoincremental"]
    ]
    if not actualizables:
        messagebox.showwarning(
            "Sin campos actualizables",
            "No hay campos que puedan actualizarse en esta tabla.",
        )
        return

    valores = []
    for campo in actualizables:
        nombre = campo["nombre"]
        if nombre == "precio_total":
            valido, kilos = validar_valor_numerico(
                "kilos",
                campos["kilos"].get().strip(),
            )
            if not valido:
                return
            total = calcular_total(kilos)
            if total is None:
                messagebox.showwarning(
                    "Kilos inválidos",
                    "Ingresa una cantidad de kilos válida para calcular el precio total.",
                )
                return
            valores.append(total)
            continue

        valor = campos[nombre].get().strip()
        if not valor and not campo["nulo"]:
            messagebox.showwarning(
                "Dato faltante",
                f"El campo {nombre} es obligatorio.",
            )
            return
        valido, valor_convertido = validar_valor(
            nombre,
            valor,
        )
        if not valido:
            return
        valores.append(valor_convertido if valor else None)

    asignaciones = ", ".join(
        f"{citar_columna(campo['nombre'])} = %s" for campo in actualizables
    )
    condiciones = " AND ".join(
        f"{citar_columna(nombre)} = %s" for nombre in claves_primarias
    )
    valores_clave = [clave[nombre] for nombre in claves_primarias]

    conexion = conectar()
    if conexion is None:
        return

    cursor = None
    try:
        cursor = conexion.cursor()
        cursor.execute(
            f"UPDATE ventas SET {asignaciones} WHERE {condiciones}",
            tuple(valores + valores_clave),
        )
        conexion.commit()
        messagebox.showinfo("Venta actualizada", "La venta se actualizó correctamente.")
        mostrar_ventas()
    except mysql.connector.Error as error:
        messagebox.showerror(
            "Error al actualizar",
            f"No fue posible actualizar la venta:\n{error}",
        )
    finally:
        if cursor is not None:
            cursor.close()
        conexion.close()


def eliminar_venta():
    clave = obtener_clave_seleccionada()
    if clave is None:
        return

    resumen = ", ".join(
        f"{nombre}: {clave[nombre]}" for nombre in claves_primarias
    )
    if not messagebox.askyesno(
        "Confirmar eliminación",
        f"¿Deseas eliminar la venta ({resumen})?",
    ):
        return

    condiciones = " AND ".join(
        f"{citar_columna(nombre)} = %s" for nombre in claves_primarias
    )
    valores_clave = [clave[nombre] for nombre in claves_primarias]

    conexion = conectar()
    if conexion is None:
        return

    cursor = None
    try:
        cursor = conexion.cursor()
        cursor.execute(
            f"DELETE FROM ventas WHERE {condiciones}",
            tuple(valores_clave),
        )
        conexion.commit()
        if cursor.rowcount:
            messagebox.showinfo("Venta eliminada", "La venta se eliminó correctamente.")
        else:
            messagebox.showinfo("Sin cambios", "No se encontró esa venta.")
        mostrar_ventas()
    except mysql.connector.Error as error:
        messagebox.showerror(
            "Error al eliminar",
            f"No fue posible eliminar la venta:\n{error}",
        )
    finally:
        if cursor is not None:
            cursor.close()
        conexion.close()


def seleccionar_venta(event=None):
    global registro_seleccionado

    seleccion = tabla.selection()
    if not seleccion:
        registro_seleccionado = None
        return

    valores = tabla.item(seleccion[0], "values")
    por_columna = {
        campo["nombre"]: valores[indice]
        for indice, campo in enumerate(columnas)
    }
    for nombre, campo in campos.items():
        if nombre == "precio_total":
            continue
        campo.delete(0, tk.END)
        campo.insert(0, por_columna[nombre])
    actualizar_precio_total()
    registro_seleccionado = {
        nombre: por_columna[nombre] for nombre in claves_primarias
    }


def crear_interfaz(ventana):
    global tabla, campos, columnas, claves_primarias, registro_seleccionado
    columnas = []
    claves_primarias = []
    campos = {}
    registro_seleccionado = None

    ventana.config(bg="light gray")

    tk.Label(
        ventana,
        text="Ventas registradas",
        font=("Arial", 16, "bold"),
        bg="light gray",
    ).pack(anchor=tk.W, padx=20, pady=(18, 8))

    if not cargar_estructura():
        return

    formulario = tk.Frame(ventana, bg="light gray")
    formulario.pack(fill=tk.X, padx=20, pady=(0, 10))
    campos_visibles = [
        campo
        for campo in columnas
        if not campo["autoincremental"] or campo["nombre"] == "id"
    ]
    for indice, campo in enumerate(campos_visibles):
        fila = indice // 3
        columna = (indice % 3) * 2
        nombre = campo["nombre"]
        etiquetas = {
            "id": "ID (automático al registrar)",
            "producto": "Producto",
            "kilos": "Kilos",
            "fecha": "Fecha (AAAA-MM-DD)",
            "precio_total": "Precio total (21 por kilo)",
        }
        tk.Label(
            formulario,
            text=f"{etiquetas.get(nombre, nombre)}:",
            bg="light gray",
        ).grid(row=fila, column=columna, sticky=tk.W, padx=(0, 5), pady=4)
        entrada = tk.Entry(formulario, width=22)
        entrada.grid(row=fila, column=columna + 1, sticky=tk.EW, padx=(0, 12), pady=4)
        campos[nombre] = entrada
        if nombre == "precio_total":
            entrada.configure(state="readonly")
        elif nombre == "kilos":
            entrada.bind("<KeyRelease>", actualizar_precio_total)
            entrada.bind("<FocusOut>", actualizar_precio_total)

    for columna in (1, 3, 5):
        formulario.grid_columnconfigure(columna, weight=1)

    botones = tk.Frame(ventana, bg="light gray")
    botones.pack(fill=tk.X, padx=20, pady=(0, 10))
    acciones = (
        ("Mostrar", mostrar_ventas),
        ("Buscar", buscar_ventas),
        ("Insertar", insertar_venta),
        ("Eliminar", eliminar_venta),
        ("Actualizar", actualizar_venta),
        ("Reporte Excel", lambda: generar_reporte_excel(tabla, "ventas")),
        ("Reporte PDF", lambda: generar_reporte_pdf(tabla, "ventas")),
    )
    for texto, comando in acciones:
        tk.Button(
            botones,
            text=texto,
            width=14,
            command=comando,
        ).pack(side=tk.LEFT, padx=(0, 8))

    marco_tabla = tk.Frame(ventana)
    marco_tabla.pack(fill=tk.BOTH, expand=True, padx=20, pady=(0, 20))

    tabla = ttk.Treeview(marco_tabla, show="headings", selectmode="browse")
    tabla.bind("<<TreeviewSelect>>", seleccionar_venta)
    barra_vertical = ttk.Scrollbar(
        marco_tabla,
        orient=tk.VERTICAL,
        command=tabla.yview,
    )
    barra_horizontal = ttk.Scrollbar(
        marco_tabla,
        orient=tk.HORIZONTAL,
        command=tabla.xview,
    )
    tabla.configure(
        yscrollcommand=barra_vertical.set,
        xscrollcommand=barra_horizontal.set,
    )

    tabla.grid(row=0, column=0, sticky="nsew")
    barra_vertical.grid(row=0, column=1, sticky="ns")
    barra_horizontal.grid(row=1, column=0, sticky="ew")
    marco_tabla.grid_rowconfigure(0, weight=1)
    marco_tabla.grid_columnconfigure(0, weight=1)

    mostrar_ventas()


def main():
    ventana = tk.Tk()
    ventana.title("VENTAS")
    ventana.geometry("1100x700")
    crear_interfaz(ventana)
    ventana.mainloop()


if __name__ == "__main__":
    main()
