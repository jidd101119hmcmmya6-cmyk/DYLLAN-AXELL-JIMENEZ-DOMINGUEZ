import tkinter as tk
from tkinter import messagebox, ttk

import mysql.connector

from reportes import generar_reporte_excel, generar_reporte_pdf


def conectar():
    try:
        return mysql.connector.connect(
            host="localhost",
            user="root",
            passwd="",
            database="tortilleria_az",
        )
    except mysql.connector.Error as error:
        messagebox.showerror(
            "Error de conexión",
            f"No fue posible conectar con la base de datos:\n{error}",
        )
        return None


def citar_identificador(nombre):
    return f"`{nombre.replace('`', '``')}`"


class VentanaTabla:
    def __init__(self, ventana, tabla_nombre, titulo):
        self.ventana = ventana
        self.tabla_nombre = tabla_nombre
        self.titulo = titulo
        self.columnas = []
        self.claves_primarias = []
        self.campos = {}
        self.registro_seleccionado = None

        self.ventana.config(bg="light gray")

        tk.Label(
            self.ventana,
            text=f"Registros de {titulo.lower()}",
            font=("Arial", 16, "bold"),
            bg="light gray",
        ).pack(anchor=tk.W, padx=20, pady=(18, 8))

        if not self.cargar_estructura():
            return

        self.crear_formulario()
        self.crear_tabla()
        self.mostrar()

    def cargar_estructura(self):
        conexion = conectar()
        if conexion is None:
            return False

        cursor = None
        try:
            cursor = conexion.cursor()
            cursor.execute(f"DESCRIBE {citar_identificador(self.tabla_nombre)}")
            for campo in cursor.fetchall():
                self.columnas.append(
                    {
                        "nombre": campo[0],
                        "nulo": campo[2] == "YES",
                        "clave": campo[3],
                        "predeterminado": campo[4],
                        "autoincremental": "auto_increment"
                        in (campo[5] or "").lower(),
                    }
                )
            self.claves_primarias = [
                campo["nombre"] for campo in self.columnas if campo["clave"] == "PRI"
            ]
            return bool(self.columnas)
        except mysql.connector.Error as error:
            messagebox.showerror(
                "Error al cargar la tabla",
                f"No fue posible consultar la estructura de "
                f"{self.tabla_nombre}:\n{error}",
            )
            return False
        finally:
            if cursor is not None:
                cursor.close()
            conexion.close()

    def crear_formulario(self):
        formulario = tk.Frame(self.ventana, bg="light gray")
        formulario.pack(fill=tk.X, padx=20, pady=(0, 10))

        for indice, campo in enumerate(self.columnas):
            fila = indice // 3
            columna = (indice % 3) * 2
            tk.Label(
                formulario,
                text=f"{campo['nombre']}:",
                bg="light gray",
            ).grid(row=fila, column=columna, sticky=tk.W, padx=(0, 5), pady=4)
            entrada = tk.Entry(formulario, width=22)
            entrada.grid(
                row=fila,
                column=columna + 1,
                sticky=tk.EW,
                padx=(0, 12),
                pady=4,
            )
            self.campos[campo["nombre"]] = entrada

        for columna in (1, 3, 5):
            formulario.grid_columnconfigure(columna, weight=1)

        botones = tk.Frame(self.ventana, bg="light gray")
        botones.pack(fill=tk.X, padx=20, pady=(0, 10))
        acciones = (
            ("Mostrar", self.mostrar),
            ("Buscar", self.buscar),
            ("Insertar", self.insertar),
            ("Actualizar", self.actualizar),
            ("Eliminar", self.eliminar),
            ("Limpiar", self.limpiar),
            (
                "Reporte Excel",
                lambda: generar_reporte_excel(self.tabla, self.titulo),
            ),
            (
                "Reporte PDF",
                lambda: generar_reporte_pdf(self.tabla, self.titulo),
            ),
        )
        for texto, comando in acciones:
            tk.Button(
                botones,
                text=texto,
                width=12,
                command=comando,
            ).pack(side=tk.LEFT, padx=(0, 8))

    def crear_tabla(self):
        marco_tabla = tk.Frame(self.ventana)
        marco_tabla.pack(fill=tk.BOTH, expand=True, padx=20, pady=(0, 20))

        identificadores = [f"col_{indice}" for indice in range(len(self.columnas))]
        self.tabla = ttk.Treeview(
            marco_tabla,
            columns=identificadores,
            show="headings",
            selectmode="browse",
        )
        self.tabla.bind("<<TreeviewSelect>>", self.seleccionar)
        for identificador, campo in zip(identificadores, self.columnas):
            self.tabla.heading(identificador, text=campo["nombre"])
            self.tabla.column(
                identificador,
                width=140,
                minwidth=80,
                anchor=tk.W,
            )

        barra_vertical = ttk.Scrollbar(
            marco_tabla,
            orient=tk.VERTICAL,
            command=self.tabla.yview,
        )
        barra_horizontal = ttk.Scrollbar(
            marco_tabla,
            orient=tk.HORIZONTAL,
            command=self.tabla.xview,
        )
        self.tabla.configure(
            yscrollcommand=barra_vertical.set,
            xscrollcommand=barra_horizontal.set,
        )
        self.tabla.grid(row=0, column=0, sticky="nsew")
        barra_vertical.grid(row=0, column=1, sticky="ns")
        barra_horizontal.grid(row=1, column=0, sticky="ew")
        marco_tabla.grid_rowconfigure(0, weight=1)
        marco_tabla.grid_columnconfigure(0, weight=1)

    def mostrar(self):
        conexion = conectar()
        if conexion is None:
            return

        cursor = None
        try:
            cursor = conexion.cursor()
            cursor.execute(
                f"SELECT * FROM {citar_identificador(self.tabla_nombre)}"
            )
            filas = cursor.fetchall()
            self.registro_seleccionado = None
            self.tabla.delete(*self.tabla.get_children())
            for fila in filas:
                self.tabla.insert("", tk.END, values=fila)
        except mysql.connector.Error as error:
            messagebox.showerror(
                "Error al consultar",
                f"No fue posible mostrar {self.tabla_nombre}:\n{error}",
            )
        finally:
            if cursor is not None:
                cursor.close()
            conexion.close()

    def buscar(self):
        filtros = [
            (campo["nombre"], self.campos[campo["nombre"]].get().strip())
            for campo in self.columnas
            if self.campos[campo["nombre"]].get().strip()
        ]
        consulta = f"SELECT * FROM {citar_identificador(self.tabla_nombre)}"
        parametros = []
        if filtros:
            condiciones = [
                f"CAST({citar_identificador(nombre)} AS CHAR) LIKE %s"
                for nombre, _ in filtros
            ]
            consulta += " WHERE " + " AND ".join(condiciones)
            parametros = [f"%{valor}%" for _, valor in filtros]

        conexion = conectar()
        if conexion is None:
            return

        cursor = None
        try:
            cursor = conexion.cursor()
            cursor.execute(consulta, tuple(parametros))
            filas = cursor.fetchall()
            self.registro_seleccionado = None
            self.tabla.delete(*self.tabla.get_children())
            for fila in filas:
                self.tabla.insert("", tk.END, values=fila)
            if not filas:
                messagebox.showinfo(
                    "Sin resultados",
                    f"No se encontraron registros en {self.tabla_nombre}.",
                )
        except mysql.connector.Error as error:
            messagebox.showerror(
                "Error al buscar",
                f"No fue posible buscar en {self.tabla_nombre}:\n{error}",
            )
        finally:
            if cursor is not None:
                cursor.close()
            conexion.close()

    def leer_valores_insertar(self):
        valores = {}
        for campo in self.columnas:
            valor = self.campos[campo["nombre"]].get().strip()
            if campo["autoincremental"] or (
                not valor
                and (campo["nulo"] or campo["predeterminado"] is not None)
            ):
                continue
            if not valor and not campo["nulo"]:
                messagebox.showwarning(
                    "Dato faltante",
                    f"El campo {campo['nombre']} es obligatorio.",
                )
                return None
            valores[campo["nombre"]] = valor if valor else None
        return valores

    def insertar(self):
        valores = self.leer_valores_insertar()
        if valores is None:
            return
        if not valores:
            messagebox.showwarning(
                "Datos faltantes",
                "Ingresa los datos antes de insertar.",
            )
            return

        nombres = list(valores)
        columnas_sql = ", ".join(citar_identificador(nombre) for nombre in nombres)
        marcadores = ", ".join(["%s"] * len(nombres))
        consulta = (
            f"INSERT INTO {citar_identificador(self.tabla_nombre)} "
            f"({columnas_sql}) VALUES ({marcadores})"
        )
        conexion = conectar()
        if conexion is None:
            return

        cursor = None
        try:
            cursor = conexion.cursor()
            cursor.execute(consulta, tuple(valores.values()))
            conexion.commit()
            messagebox.showinfo(
                "Registro insertado",
                f"El registro se agregó a {self.tabla_nombre}.",
            )
            self.limpiar()
            self.mostrar()
        except mysql.connector.Error as error:
            messagebox.showerror(
                "Error al insertar",
                f"No fue posible insertar el registro:\n{error}",
            )
        finally:
            if cursor is not None:
                cursor.close()
            conexion.close()

    def clave_seleccionada(self):
        if not self.claves_primarias:
            messagebox.showwarning(
                "Clave primaria requerida",
                f"La tabla {self.tabla_nombre} no tiene clave primaria; "
                "no se puede identificar con seguridad el registro.",
            )
            return None
        if self.registro_seleccionado is None:
            messagebox.showwarning(
                "Selecciona un registro",
                "Selecciona un registro de la tabla antes de actualizarlo o eliminarlo.",
            )
            return None
        return self.registro_seleccionado

    def actualizar(self):
        clave = self.clave_seleccionada()
        if clave is None:
            return

        nombres_clave = set(self.claves_primarias)
        actualizables = [
            campo
            for campo in self.columnas
            if campo["nombre"] not in nombres_clave and not campo["autoincremental"]
        ]
        if not actualizables:
            messagebox.showwarning(
                "Sin campos actualizables",
                "No hay campos que puedan actualizarse en esta tabla.",
            )
            return

        valores = []
        for campo in actualizables:
            valor = self.campos[campo["nombre"]].get().strip()
            if not valor and not campo["nulo"]:
                messagebox.showwarning(
                    "Dato faltante",
                    f"El campo {campo['nombre']} es obligatorio.",
                )
                return
            valores.append(valor if valor else None)

        asignaciones = ", ".join(
            f"{citar_identificador(campo['nombre'])} = %s"
            for campo in actualizables
        )
        condiciones = " AND ".join(
            f"{citar_identificador(nombre)} = %s"
            for nombre in self.claves_primarias
        )
        valores_clave = [clave[nombre] for nombre in self.claves_primarias]
        conexion = conectar()
        if conexion is None:
            return

        cursor = None
        try:
            cursor = conexion.cursor()
            cursor.execute(
                f"UPDATE {citar_identificador(self.tabla_nombre)} "
                f"SET {asignaciones} WHERE {condiciones}",
                tuple(valores + valores_clave),
            )
            conexion.commit()
            if cursor.rowcount:
                messagebox.showinfo(
                    "Registro actualizado",
                    "El registro se actualizó correctamente.",
                )
            else:
                messagebox.showinfo(
                    "Sin cambios",
                    "No se modificó ningún dato del registro.",
                )
            self.mostrar()
        except mysql.connector.Error as error:
            messagebox.showerror(
                "Error al actualizar",
                f"No fue posible actualizar el registro:\n{error}",
            )
        finally:
            if cursor is not None:
                cursor.close()
            conexion.close()

    def eliminar(self):
        clave = self.clave_seleccionada()
        if clave is None:
            return

        resumen = ", ".join(
            f"{nombre}: {clave[nombre]}" for nombre in self.claves_primarias
        )
        if not messagebox.askyesno(
            "Confirmar eliminación",
            f"¿Deseas eliminar el registro ({resumen})?",
        ):
            return

        condiciones = " AND ".join(
            f"{citar_identificador(nombre)} = %s"
            for nombre in self.claves_primarias
        )
        valores_clave = [clave[nombre] for nombre in self.claves_primarias]
        conexion = conectar()
        if conexion is None:
            return

        cursor = None
        try:
            cursor = conexion.cursor()
            cursor.execute(
                f"DELETE FROM {citar_identificador(self.tabla_nombre)} "
                f"WHERE {condiciones}",
                tuple(valores_clave),
            )
            conexion.commit()
            if cursor.rowcount:
                messagebox.showinfo(
                    "Registro eliminado",
                    "El registro se eliminó correctamente.",
                )
            else:
                messagebox.showinfo(
                    "Sin resultados",
                    "No se encontró ese registro.",
                )
            self.limpiar()
            self.mostrar()
        except mysql.connector.Error as error:
            messagebox.showerror(
                "Error al eliminar",
                f"No fue posible eliminar el registro:\n{error}",
            )
        finally:
            if cursor is not None:
                cursor.close()
            conexion.close()

    def seleccionar(self, event=None):
        seleccion = self.tabla.selection()
        if not seleccion:
            self.registro_seleccionado = None
            return

        valores = self.tabla.item(seleccion[0], "values")
        por_columna = {
            campo["nombre"]: valores[indice]
            for indice, campo in enumerate(self.columnas)
        }
        for nombre, entrada in self.campos.items():
            entrada.delete(0, tk.END)
            entrada.insert(0, por_columna[nombre])
        self.registro_seleccionado = {
            nombre: por_columna[nombre] for nombre in self.claves_primarias
        }

    def limpiar(self):
        self.registro_seleccionado = None
        for campo in self.campos.values():
            campo.delete(0, tk.END)
        if hasattr(self, "tabla"):
            self.tabla.selection_remove(self.tabla.selection())
