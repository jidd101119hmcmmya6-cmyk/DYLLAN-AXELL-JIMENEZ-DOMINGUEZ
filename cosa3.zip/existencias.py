import tkinter as tk
from decimal import Decimal, InvalidOperation
from tkinter import messagebox, ttk

import mysql.connector


def conectar():
    try:
        return mysql.connector.connect(
            host="localhost",
            user="root",
            passwd="",
            database="INVENTARIO",
        )
    except mysql.connector.Error as error:
        messagebox.showerror(
            "Error de conexión",
            f"No fue posible conectar con la base de datos:\n{error}",
        )
        return None


def leer_datos():
    codigo = caja_codigo.get().strip()
    lote = caja_lote.get().strip()
    cantidad_texto = caja_cantidad.get().strip()

    if not codigo or not lote or not cantidad_texto:
        messagebox.showwarning(
            "Datos incompletos",
            "Ingresa el código del producto, el lote y la cantidad.",
        )
        return None

    if len(codigo) > 20 or len(lote) > 20:
        messagebox.showwarning(
            "Dato demasiado largo",
            "El código del producto y el lote admiten hasta 20 caracteres.",
        )
        return None

    try:
        cantidad = Decimal(cantidad_texto)
    except InvalidOperation:
        messagebox.showwarning(
            "Cantidad inválida",
            "La cantidad debe ser un número, por ejemplo 10 o 2.5.",
        )
        return None

    if not cantidad.is_finite() or cantidad < 0:
        messagebox.showwarning(
            "Cantidad inválida",
            "La cantidad debe ser un número finito igual o mayor que cero.",
        )
        return None

    return codigo, lote, cantidad


def mostrar_existencias():
    conexion = conectar()
    if conexion is None:
        return

    cursor = None
    try:
        cursor = conexion.cursor()
        cursor.execute(
            """
            SELECT E.PRO_CODIGO_K, P.PRO_DESCRIPCION,
                   E.EXI_LOTE, E.EXI_CANTIDAD
            FROM EXISTENCIAS AS E
            INNER JOIN PRODUCTOS AS P
                ON P.PRO_CODIGO_K = E.PRO_CODIGO_K
            ORDER BY E.PRO_CODIGO_K, E.EXI_LOTE
            """
        )
        filas = cursor.fetchall()

        tabla.delete(*tabla.get_children())
        for fila in filas:
            tabla.insert("", tk.END, values=fila)
    except mysql.connector.Error as error:
        messagebox.showerror(
            "Error al consultar",
            f"No fue posible mostrar las existencias:\n{error}",
        )
    finally:
        if cursor is not None:
            cursor.close()
        conexion.close()


def insertar_existencia():
    datos = leer_datos()
    if datos is None:
        return

    conexion = conectar()
    if conexion is None:
        return

    cursor = None
    try:
        cursor = conexion.cursor()
        cursor.execute(
            """
            INSERT INTO EXISTENCIAS (PRO_CODIGO_K, EXI_LOTE, EXI_CANTIDAD)
            VALUES (%s, %s, %s)
            """,
            datos,
        )
        conexion.commit()
        limpiar_campos()
        mostrar_existencias()
    except mysql.connector.Error as error:
        messagebox.showerror(
            "Error al registrar",
            "No fue posible registrar la existencia. Verifica que el producto "
            "exista y que no haya ya un registro con el mismo código y lote.\n"
            f"Detalle: {error}",
        )
    finally:
        if cursor is not None:
            cursor.close()
        conexion.close()


def actualizar_existencia():
    datos = leer_datos()
    if datos is None:
        return

    conexion = conectar()
    if conexion is None:
        return

    cursor = None
    try:
        cursor = conexion.cursor()
        cursor.execute(
            """
            UPDATE EXISTENCIAS
            SET EXI_CANTIDAD = %s
            WHERE PRO_CODIGO_K = %s AND EXI_LOTE = %s
            """,
            (datos[2], datos[0], datos[1]),
        )
        conexion.commit()

        if cursor.rowcount == 0:
            messagebox.showinfo(
                "Sin cambios",
                "No se encontró esa existencia o la cantidad ya tenía ese valor.",
            )
        mostrar_existencias()
    except mysql.connector.Error as error:
        messagebox.showerror(
            "Error al actualizar",
            f"No fue posible actualizar la existencia:\n{error}",
        )
    finally:
        if cursor is not None:
            cursor.close()
        conexion.close()


def buscar_existencia():
    codigo = caja_codigo.get().strip()
    lote = caja_lote.get().strip()
    if not codigo:
        messagebox.showwarning(
            "Dato faltante",
            "Ingresa el código del producto que deseas buscar.",
        )
        return

    conexion = conectar()
    if conexion is None:
        return

    cursor = None
    try:
        cursor = conexion.cursor()
        consulta = """
            SELECT E.PRO_CODIGO_K, P.PRO_DESCRIPCION,
                   E.EXI_LOTE, E.EXI_CANTIDAD
            FROM EXISTENCIAS AS E
            INNER JOIN PRODUCTOS AS P
                ON P.PRO_CODIGO_K = E.PRO_CODIGO_K
            WHERE E.PRO_CODIGO_K = %s
        """
        parametros = [codigo]
        if lote:
            consulta += " AND E.EXI_LOTE = %s"
            parametros.append(lote)
        consulta += " ORDER BY E.EXI_LOTE"

        cursor.execute(consulta, tuple(parametros))
        filas = cursor.fetchall()

        tabla.delete(*tabla.get_children())
        for fila in filas:
            tabla.insert("", tk.END, values=fila)

        if len(filas) == 1:
            caja_lote.delete(0, tk.END)
            caja_lote.insert(0, filas[0][2])
            caja_cantidad.delete(0, tk.END)
            caja_cantidad.insert(0, str(filas[0][3]))
        elif not filas:
            messagebox.showinfo(
                "Sin resultados",
                "No se encontraron existencias con esos datos.",
            )
    except mysql.connector.Error as error:
        messagebox.showerror(
            "Error al buscar",
            f"No fue posible buscar la existencia:\n{error}",
        )
    finally:
        if cursor is not None:
            cursor.close()
        conexion.close()


def eliminar_existencia():
    codigo = caja_codigo.get().strip()
    lote = caja_lote.get().strip()
    if not codigo or not lote:
        messagebox.showwarning(
            "Datos faltantes",
            "Ingresa el código del producto y el lote que deseas eliminar.",
        )
        return

    if not messagebox.askyesno(
        "Confirmar eliminación",
        f"¿Deseas eliminar la existencia del producto {codigo}, lote {lote}?",
    ):
        return

    conexion = conectar()
    if conexion is None:
        return

    cursor = None
    try:
        cursor = conexion.cursor()
        cursor.execute(
            """
            DELETE FROM EXISTENCIAS
            WHERE PRO_CODIGO_K = %s AND EXI_LOTE = %s
            """,
            (codigo, lote),
        )
        conexion.commit()

        if cursor.rowcount == 0:
            messagebox.showinfo(
                "Sin resultados",
                "No se encontró una existencia con ese código y lote.",
            )
        else:
            limpiar_campos()
            mostrar_existencias()
    except mysql.connector.Error as error:
        messagebox.showerror(
            "Error al eliminar",
            f"No fue posible eliminar la existencia:\n{error}",
        )
    finally:
        if cursor is not None:
            cursor.close()
        conexion.close()


def limpiar_campos():
    caja_codigo.delete(0, tk.END)
    caja_lote.delete(0, tk.END)
    caja_cantidad.delete(0, tk.END)


def crear_interfaz(contenedor):
    global caja_codigo, caja_lote, caja_cantidad, tabla

    contenedor.config(bg="light gray")
    tk.Label(contenedor, text="Código producto:").place(x=25, y=20)
    caja_codigo = tk.Entry(contenedor, width=20)
    caja_codigo.place(x=135, y=20)

    tk.Label(contenedor, text="Lote:").place(x=330, y=20)
    caja_lote = tk.Entry(contenedor, width=20)
    caja_lote.place(x=375, y=20)

    tk.Label(contenedor, text="Cantidad:").place(x=25, y=60)
    caja_cantidad = tk.Entry(contenedor, width=20)
    caja_cantidad.place(x=135, y=60)

    botones = (
        ("Mostrar", mostrar_existencias),
        ("Registrar", insertar_existencia),
        ("Actualizar", actualizar_existencia),
        ("Buscar", buscar_existencia),
        ("Eliminar", eliminar_existencia),
    )
    for indice, (texto, comando) in enumerate(botones):
        tk.Button(
            contenedor,
            text=texto,
            width=12,
            command=comando,
        ).place(x=25 + indice * 150, y=100)

    tabla = ttk.Treeview(
        contenedor,
        columns=("codigo", "descripcion", "lote", "cantidad"),
        show="headings",
        height=14,
    )
    tabla.heading("codigo", text="CÓDIGO")
    tabla.heading("descripcion", text="PRODUCTO")
    tabla.heading("lote", text="LOTE")
    tabla.heading("cantidad", text="CANTIDAD")
    tabla.column("codigo", width=130)
    tabla.column("descripcion", width=340)
    tabla.column("lote", width=130)
    tabla.column("cantidad", width=120, anchor=tk.CENTER)
    tabla.place(x=25, y=150)

    tk.Button(
        contenedor,
        text="Salir",
        width=12,
        command=contenedor.winfo_toplevel().destroy,
    ).place(x=680, y=480)

    mostrar_existencias()


def main():
    ventana = tk.Tk()
    ventana.title("CONTROL DE EXISTENCIAS")
    ventana.geometry("820x540")
    ventana.config(bg="light gray")
    crear_interfaz(ventana)
    ventana.mainloop()


if __name__ == "__main__":
    main()
