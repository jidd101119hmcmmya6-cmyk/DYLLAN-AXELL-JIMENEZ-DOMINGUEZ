import os
import re
from tkinter import filedialog, messagebox
from xml.sax.saxutils import escape

import pandas as pd
from reportlab.lib import colors
from reportlab.lib.pagesizes import landscape, letter
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import inch
from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle


def _obtener_datos(tabla):
    identificadores = tabla["columns"]
    columnas = [
        tabla.heading(identificador, "text") or str(identificador)
        for identificador in identificadores
    ]
    filas = [
        tabla.item(fila, "values")
        for fila in tabla.get_children()
    ]
    return columnas, filas


def _nombre_archivo(titulo, extension):
    nombre = re.sub(r"[^A-Za-z0-9_-]+", "_", titulo.strip()).strip("_").lower()
    return f"reporte_{nombre or 'tortilleria'}.{extension}"


def _elegir_destino(tabla, titulo, extension, tipo):
    columnas, filas = _obtener_datos(tabla)
    parent = tabla.winfo_toplevel()
    if not columnas or not filas:
        messagebox.showwarning(
            "Sin datos",
            "No hay datos en la tabla para generar el reporte.",
            parent=parent,
        )
        return None, None, None, parent

    ruta = filedialog.asksaveasfilename(
        parent=parent,
        title=f"Guardar reporte {tipo}",
        initialfile=_nombre_archivo(titulo, extension),
        defaultextension=f".{extension}",
        filetypes=[(f"Archivo {tipo}", f"*.{extension}")],
    )
    if not ruta:
        return None, None, None, parent
    return columnas, filas, ruta, parent


def _abrir_archivo(ruta, parent):
    try:
        os.startfile(ruta)
    except OSError as error:
        messagebox.showerror(
            "No se pudo abrir el reporte",
            f"El archivo se guardó, pero no fue posible abrirlo:\n{error}",
            parent=parent,
        )


def generar_reporte_excel(tabla, titulo):
    columnas, filas, ruta, parent = _elegir_destino(
        tabla,
        titulo,
        "xlsx",
        "Excel",
    )
    if ruta is None:
        return

    try:
        pd.DataFrame(filas, columns=columnas).to_excel(ruta, index=False)
    except (OSError, ValueError, ImportError) as error:
        messagebox.showerror(
            "Error al generar Excel",
            f"No fue posible guardar el reporte:\n{error}",
            parent=parent,
        )
        return

    _abrir_archivo(ruta, parent)


def generar_reporte_pdf(tabla, titulo):
    columnas, filas, ruta, parent = _elegir_destino(
        tabla,
        titulo,
        "pdf",
        "PDF",
    )
    if ruta is None:
        return

    estilos = getSampleStyleSheet()
    estilo_titulo = estilos["Title"]
    estilo_celda = ParagraphStyle(
        "CeldaReporte",
        parent=estilos["BodyText"],
        fontName="Helvetica",
        fontSize=7,
        leading=8,
        spaceAfter=0,
    )
    estilo_encabezado = ParagraphStyle(
        "EncabezadoReporte",
        parent=estilo_celda,
        fontName="Helvetica-Bold",
        textColor=colors.white,
    )
    titulo_reporte = f"Reporte de {titulo.title()}"
    contenido = [
        Paragraph(escape(titulo_reporte), estilo_titulo),
        Spacer(1, 0.2 * inch),
    ]
    datos_tabla = [
        [Paragraph(escape(str(columna)), estilo_encabezado) for columna in columnas]
    ]
    datos_tabla.extend(
        [
            Paragraph(
                escape("" if valor is None else str(valor)),
                estilo_celda,
            )
            for valor in fila
        ]
        for fila in filas
    )

    ancho_pagina, _ = landscape(letter)
    margen = 0.35 * inch
    ancho_disponible = ancho_pagina - (2 * margen)
    longitudes = [
        min(
            28,
            max(
                6,
                len(str(columna)),
                *(len(str(fila[indice])) for fila in filas),
            ),
        )
        for indice, columna in enumerate(columnas)
    ]
    total_longitudes = sum(longitudes)
    anchos_columnas = [
        ancho_disponible * longitud / total_longitudes
        for longitud in longitudes
    ]
    tabla_pdf = Table(
        datos_tabla,
        colWidths=anchos_columnas,
        repeatRows=1,
        hAlign="LEFT",
    )
    tabla_pdf.setStyle(
        TableStyle(
            [
                ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#1F4E78")),
                ("GRID", (0, 0), (-1, -1), 0.35, colors.HexColor("#B7C9D6")),
                ("VALIGN", (0, 0), (-1, -1), "TOP"),
                ("LEFTPADDING", (0, 0), (-1, -1), 4),
                ("RIGHTPADDING", (0, 0), (-1, -1), 4),
                ("TOPPADDING", (0, 0), (-1, -1), 4),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
            ]
        )
    )
    contenido.append(tabla_pdf)

    try:
        documento = SimpleDocTemplate(
            ruta,
            pagesize=landscape(letter),
            leftMargin=margen,
            rightMargin=margen,
            topMargin=margen,
            bottomMargin=margen,
            title=titulo_reporte,
        )
        documento.build(contenido)
    except (OSError, ValueError) as error:
        messagebox.showerror(
            "Error al generar PDF",
            f"No fue posible guardar el reporte:\n{error}",
            parent=parent,
        )
        return

    _abrir_archivo(ruta, parent)
