import tkinter as tk

from crud_tortilleria import VentanaTabla


def crear_interfaz(ventana):
    return VentanaTabla(ventana, "movimientos", "MOVIMIENTOS")


def main():
    ventana = tk.Tk()
    ventana.title("MOVIMIENTOS")
    ventana.geometry("1100x700")
    crear_interfaz(ventana)
    ventana.mainloop()


if __name__ == "__main__":
    main()
