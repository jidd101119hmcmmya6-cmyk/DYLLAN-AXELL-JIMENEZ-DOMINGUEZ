import tkinter as tk

import movimientos_tortilleria
import pedidos
import producto
import ventas2


def mostrar_pantalla(crear_interfaz):
    for widget in marco_contenido.winfo_children():
        widget.destroy()
    crear_interfaz(marco_contenido)


def mostrar_inicio():
    for widget in marco_contenido.winfo_children():
        widget.destroy()

    tk.Label(
        marco_contenido,
        text="TORTILLERÍA AZ",
        font=("Arial", 22, "bold"),
        bg="white",
        fg="RoyalBlue4",
        padx=20,
        pady=15,
    ).pack(fill=tk.X, pady=(10, 20))

    tk.Label(
        marco_contenido,
        text="Bienvenido al sistema de administración de la tortillería",
        font=("Arial", 16, "bold"),
        bg="lightyellow",
        fg="RoyalBlue4",
    ).pack(pady=40)


def crear_boton_menu(marco, texto, comando):
    return tk.Button(
        marco,
        text=texto,
        command=comando,
        width=20,
        height=2,
        bg="Royalblue2",
        fg="white",
        font=("Arial", 11, "bold"),
        activebackground="blue",
        activeforeground="white",
        relief="flat",
        bd=0,
    )


def main():
    global raiz, marco_contenido
    raiz = tk.Tk()
    raiz.title("Tortillería AZ - Sistema de administración")
    raiz.state("zoomed")

    pantallas = (
        ("PRODUCTOS", producto.crear_interfaz),
        ("VENTAS", ventas2.crear_interfaz),
        ("MOVIMIENTOS", movimientos_tortilleria.crear_interfaz),
        ("PEDIDOS", pedidos.crear_interfaz),
    )

    marco_menu = tk.Frame(raiz, width=220, bg="Royalblue3")
    marco_menu.pack(side=tk.LEFT, fill=tk.Y)
    marco_menu.pack_propagate(False)

    marco_contenido = tk.Frame(raiz, bg="lightyellow")
    marco_contenido.pack(side=tk.RIGHT, expand=True, fill=tk.BOTH)

    crear_boton_menu(marco_menu, "INICIO", mostrar_inicio).pack(
        pady=10,
        padx=10,
    )
    for etiqueta, crear_interfaz in pantallas:
        crear_boton_menu(
            marco_menu,
            etiqueta,
            lambda c=crear_interfaz: mostrar_pantalla(c),
        ).pack(pady=10, padx=10)
    crear_boton_menu(marco_menu, "SALIR", raiz.destroy).pack(
        pady=10,
        padx=10,
    )

    mostrar_inicio()
    raiz.mainloop()


if __name__ == "__main__":
    main()
