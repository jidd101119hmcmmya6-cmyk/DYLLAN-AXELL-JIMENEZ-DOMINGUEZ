import tkinter as tk
from datetime import datetime
from decimal import Decimal, InvalidOperation
from tkinter import messagebox, ttk

import mysql.connector


def conectar():
    try:
        return mysql.connector.connect(
            host="localhost",
            user="root",
            passwd="",
            database="INVENTARIO",
        )
    except mysql.connector.Error as error:
        messagebox.showerror(
            "Error de conexión",
            f"No fue posible conectar con la base de datos:\n{error}",
        )
        return None


def cargar_productos():
    conexion = conectar()
    if conexion is None:
        return []

    cursor = None
    try:
        cursor = conexion.cursor()
        cursor.execute(
            "SELECT PRO_CODIGO_K, PRO_DESCRIPCION FROM PRODUCTOS ORDER BY PRO_CODIGO_K"
        )
        return cursor.fetchall()
    except mysql.connector.Error as error:
        messagebox.showerror(
            "Error al cargar productos",
            f"No fue posible consultar los productos:\n{error}",
        )
        return []
    finally:
        if cursor is not None:
            cursor.close()
        conexion.close()


def cargar_lotes(producto_codigo):
    if not producto_codigo:
        return []

    conexion = conectar()
    if conexion is None:
        return []

    cursor = None
    try:
        cursor = conexion.cursor()
        cursor.execute(
            """
            SELECT EXI_LOTE, EXI_CANTIDAD
            FROM EXISTENCIAS
            WHERE PRO_CODIGO_K = %s
            ORDER BY EXI_LOTE
            """,
            (producto_codigo,),
        )
        return cursor.fetchall()
    except mysql.connector.Error as error:
        messagebox.showerror(
            "Error al cargar lotes",
            f"No fue posible consultar los lotes:\n{error}",
        )
        return []
    finally:
        if cursor is not None:
            cursor.close()
        conexion.close()


def obtener_stock_actual(producto_codigo, lote):
    conexion = conectar()
    if conexion is None:
        return Decimal("0")

    cursor = None
    try:
        cursor = conexion.cursor()
        cursor.execute(
            "SELECT EXI_CANTIDAD FROM EXISTENCIAS WHERE PRO_CODIGO_K = %s AND EXI_LOTE = %s",
            (producto_codigo, lote),
        )
        fila = cursor.fetchone()
        if fila is None:
            return Decimal("0")
        return Decimal(str(fila[0]))
    except mysql.connector.Error:
        return Decimal("0")
    finally:
        if cursor is not None:
            cursor.close()
        conexion.close()


def leer_datos():
    codigo = combo_producto.get().strip()
    lote = combo_lote.get().strip()
    movimiento = combo_tipo.get().strip()
    fecha_texto = campo_fecha.get().strip()
    costo_texto = campo_costo.get().strip()
    cantidad_texto = campo_cantidad.get().strip()

    if not codigo or not lote or not movimiento or not fecha_texto:
        messagebox.showwarning(
            "Datos incompletos",
            "Selecciona producto, lote, tipo de movimiento y fecha.",
        )
        return None

    try:
        fecha = datetime.strptime(fecha_texto, "%d/%m/%Y").date()
    except ValueError:
        messagebox.showwarning(
            "Fecha inválida",
            "La fecha debe tener el formato dd/mm/yyyy.",
        )
        return None

    if not costo_texto:
        costo = Decimal("0")
    else:
        try:
            costo = Decimal(costo_texto)
        except InvalidOperation:
            messagebox.showwarning(
                "Costo inválido",
                "El costo debe ser un número válido.",
            )
            return None

    if not cantidad_texto:
        messagebox.showwarning(
            "Cantidad inválida",
            "Ingresa la cantidad del movimiento.",
        )
        return None

    try:
        cantidad = Decimal(cantidad_texto)
    except InvalidOperation:
        messagebox.showwarning(
            "Cantidad inválida",
            "La cantidad debe ser un número válido.",
        )
        return None

    if cantidad <= 0:
        messagebox.showwarning(
            "Cantidad inválida",
            "La cantidad debe ser mayor que cero.",
        )
        return None

    if costo < 0:
        messagebox.showwarning(
            "Costo inválido",
            "El costo no puede ser negativo.",
        )
        return None

    if movimiento == "SAL":
        stock_actual = obtener_stock_actual(codigo, lote)
        if cantidad > stock_actual:
            messagebox.showwarning(
                "Stock insuficiente",
                f"La salida de {cantidad} supera el stock disponible ({stock_actual}) en ese lote.",
            )
            return None

    total = costo * cantidad
    return codigo, lote, movimiento, fecha, costo, cantidad, total


def guardar_movimiento():
    datos = leer_datos()
    if datos is None:
        return

    codigo, lote, movimiento, fecha, costo, cantidad, total = datos
    conexion = conectar()
    if conexion is None:
        return

    cursor = None
    try:
        cursor = conexion.cursor()
        cursor.execute(
            "SELECT IFNULL(MAX(MOV_CODIGO_K), 0) + 1 FROM MOVIMIENTOS WHERE PRO_CODIGO_K = %s AND EXI_LOTE = %s",
            (codigo, lote),
        )
        siguiente_codigo = cursor.fetchone()[0]

        cursor.execute(
            """
            INSERT INTO MOVIMIENTOS (
                MOV_CODIGO_K, MOV_MOVIMIENTO, MOV_FECHA,
                PRO_CODIGO_K, EXI_LOTE, MOV_COSTO,
                MOV_CANTIDAD, MOV_TOTAL
            )
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
            """,
            (
                siguiente_codigo,
                movimiento,
                fecha.strftime("%Y-%m-%d"),
                codigo,
                lote,
                float(costo),
                float(cantidad),
                float(total),
            ),
        )

        if movimiento == "ENT":
            cursor.execute(
                """
                INSERT INTO EXISTENCIAS (PRO_CODIGO_K, EXI_LOTE, EXI_CANTIDAD)
                VALUES (%s, %s, %s)
                ON DUPLICATE KEY UPDATE EXI_CANTIDAD = EXI_CANTIDAD + VALUES(EXI_CANTIDAD)
                """,
                (codigo, lote, float(cantidad)),
            )
        else:
            cursor.execute(
                """
                UPDATE EXISTENCIAS
                SET EXI_CANTIDAD = EXI_CANTIDAD - %s
                WHERE PRO_CODIGO_K = %s AND EXI_LOTE = %s
                """,
                (float(cantidad), codigo, lote),
            )

        conexion.commit()
        limpiar_campos()
        mostrar_movimientos()
        messagebox.showinfo("Movimiento guardado", "El movimiento se registró correctamente.")
    except mysql.connector.Error as error:
        messagebox.showerror(
            "Error al registrar movimiento",
            f"No fue posible guardar el movimiento:\n{error}",
        )
    finally:
        if cursor is not None:
            cursor.close()
        conexion.close()


def mostrar_movimientos():
    conexion = conectar()
    if conexion is None:
        return

    cursor = None
    try:
        cursor = conexion.cursor()
        cursor.execute(
            """
            SELECT M.MOV_CODIGO_K, M.MOV_MOVIMIENTO, M.MOV_FECHA,
                   M.PRO_CODIGO_K, P.PRO_DESCRIPCION,
                   M.EXI_LOTE, M.MOV_CANTIDAD, M.MOV_COSTO, M.MOV_TOTAL
            FROM MOVIMIENTOS AS M
            INNER JOIN PRODUCTOS AS P
                ON P.PRO_CODIGO_K = M.PRO_CODIGO_K
            ORDER BY M.MOV_FECHA DESC, M.MOV_CODIGO_K DESC
            """
        )
        filas = cursor.fetchall()

        tabla.delete(*tabla.get_children())
        for fila in filas:
            tabla.insert("", tk.END, values=fila)
    except mysql.connector.Error as error:
        messagebox.showerror(
            "Error al consultar movimientos",
            f"No fue posible mostrar los movimientos:\n{error}",
        )
    finally:
        if cursor is not None:
            cursor.close()
        conexion.close()


def buscar_movimientos():
    codigo = combo_producto.get().strip()
    lote = combo_lote.get().strip()
    tipo = combo_tipo.get().strip()
    fecha_texto = campo_fecha.get().strip()

    conexion = conectar()
    if conexion is None:
        return

    cursor = None
    try:
        cursor = conexion.cursor()
        query = """
            SELECT M.MOV_CODIGO_K, M.MOV_MOVIMIENTO, M.MOV_FECHA,
                   M.PRO_CODIGO_K, P.PRO_DESCRIPCION,
                   M.EXI_LOTE, M.MOV_CANTIDAD, M.MOV_COSTO, M.MOV_TOTAL
            FROM MOVIMIENTOS AS M
            INNER JOIN PRODUCTOS AS P
                ON P.PRO_CODIGO_K = M.PRO_CODIGO_K
            WHERE 1 = 1
        """
        params = []

        if codigo:
            query += " AND M.PRO_CODIGO_K = %s"
            params.append(codigo)
        if lote:
            query += " AND M.EXI_LOTE = %s"
            params.append(lote)
        if tipo and tipo != "TODOS":
            query += " AND M.MOV_MOVIMIENTO = %s"
            params.append(tipo)
        if fecha_texto:
            try:
                fecha_sql = datetime.strptime(fecha_texto, "%d/%m/%Y").strftime("%Y-%m-%d")
            except ValueError:
                messagebox.showwarning(
                    "Fecha inválida",
                    "La fecha debe tener el formato dd/mm/yyyy.",
                )
                return
            query += " AND M.MOV_FECHA = %s"
            params.append(fecha_sql)

        query += " ORDER BY M.MOV_FECHA DESC, M.MOV_CODIGO_K DESC"
        cursor.execute(query, tuple(params))
        filas = cursor.fetchall()

        tabla.delete(*tabla.get_children())
        for fila in filas:
            tabla.insert("", tk.END, values=fila)
    except mysql.connector.Error as error:
        messagebox.showerror(
            "Error al buscar movimientos",
            f"No fue posible buscar los movimientos:\n{error}",
        )
    finally:
        if cursor is not None:
            cursor.close()
        conexion.close()


def limpiar_campos():
    combo_producto.set("")
    combo_lote.set("")
    combo_tipo.set("ENT")
    campo_fecha.delete(0, tk.END)
    campo_costo.delete(0, tk.END)
    campo_cantidad.delete(0, tk.END)
    campo_fecha.insert(0, datetime.now().strftime("%d/%m/%Y"))


def on_producto_seleccionado(event=None):
    codigo = combo_producto.get().strip()
    if not codigo:
        combo_lote.set("")
        combo_lote['values'] = []
        return

    lotes = cargar_lotes(codigo)
    combo_lote['values'] = [l[0] for l in lotes]
    if lotes:
        combo_lote.set(lotes[0][0])
    else:
        combo_lote.set("")


def llenar_combobox_producto():
    productos = cargar_productos()
    combo_producto['values'] = [p[0] for p in productos]
    if productos:
        combo_producto.set(productos[0][0])
        on_producto_seleccionado()
    else:
        combo_producto.set("")
        combo_lote['values'] = []
        combo_lote.set("")


def crear_interfaz(contenedor):
    global combo_producto, combo_lote, combo_tipo, campo_fecha, campo_costo, campo_cantidad, tabla

    contenedor.config(bg="light gray")
    tk.Label(contenedor, text="Producto:").place(x=20, y=20)
    combo_producto = ttk.Combobox(contenedor, width=25, state="readonly")
    combo_producto.place(x=100, y=20)
    combo_producto.bind("<<ComboboxSelected>>", on_producto_seleccionado)

    tk.Label(contenedor, text="Lote:").place(x=360, y=20)
    combo_lote = ttk.Combobox(contenedor, width=20, state="readonly")
    combo_lote.place(x=420, y=20)

    tk.Label(contenedor, text="Tipo:").place(x=620, y=20)
    combo_tipo = ttk.Combobox(contenedor, width=10, state="readonly")
    combo_tipo['values'] = ["ENT", "SAL"]
    combo_tipo.set("ENT")
    combo_tipo.place(x=680, y=20)

    tk.Label(contenedor, text="Fecha (dd/mm/yyyy):").place(x=20, y=60)
    campo_fecha = tk.Entry(contenedor, width=15)
    campo_fecha.place(x=180, y=60)
    campo_fecha.insert(0, datetime.now().strftime("%d/%m/%Y"))

    tk.Label(contenedor, text="Costo unitario:").place(x=330, y=60)
    campo_costo = tk.Entry(contenedor, width=15)
    campo_costo.place(x=440, y=60)

    tk.Label(contenedor, text="Cantidad:").place(x=620, y=60)
    campo_cantidad = tk.Entry(contenedor, width=15)
    campo_cantidad.place(x=700, y=60)

    tk.Button(contenedor, text="Registrar", width=12, command=guardar_movimiento).place(x=20, y=100)
    tk.Button(contenedor, text="Buscar", width=12, command=buscar_movimientos).place(x=160, y=100)
    tk.Button(contenedor, text="Mostrar", width=12, command=mostrar_movimientos).place(x=300, y=100)
    tk.Button(contenedor, text="Limpiar", width=12, command=limpiar_campos).place(x=440, y=100)
    tk.Button(
        contenedor,
        text="Salir",
        width=12,
        command=contenedor.winfo_toplevel().destroy,
    ).place(x=960, y=490)

    tabla = ttk.Treeview(
        contenedor,
        columns=(
            "codigo",
            "tipo",
            "fecha",
            "descripcion",
            "lote",
            "cantidad",
            "costo",
            "total",
        ),
        show="headings",
        height=16,
    )
    tabla.heading("codigo", text="CÓDIGO")
    tabla.heading("tipo", text="TIPO")
    tabla.heading("fecha", text="FECHA")
    tabla.heading("descripcion", text="DESCRIPCIÓN")
    tabla.heading("lote", text="LOTE")
    tabla.heading("cantidad", text="CANTIDAD")
    tabla.heading("costo", text="COSTO")
    tabla.heading("total", text="TOTAL")
    tabla.column("codigo", width=90)
    tabla.column("tipo", width=80)
    tabla.column("fecha", width=90)
    tabla.column("descripcion", width=230)
    tabla.column("lote", width=100)
    tabla.column("cantidad", width=100)
    tabla.column("costo", width=100)
    tabla.column("total", width=100)
    tabla.place(x=20, y=150)

    llenar_combobox_producto()
    mostrar_movimientos()


def main():
    ventana = tk.Tk()
    ventana.title("MOVIMIENTOS DE INVENTARIO")
    ventana.geometry("1100x560")
    ventana.config(bg="light gray")
    crear_interfaz(ventana)
    ventana.mainloop()


if __name__ == "__main__":
    main()
