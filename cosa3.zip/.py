import tkinter as tk
from tkinter import messagebox, ttk

import mysql.connector
import existencias
import MOVIMIENTOS


def conectar():
    try:
        conexion = mysql.connector.connect(
            host="localhost",
            user="root",
            passwd="",
            database="inventario",
        )
    except mysql.connector.Error as error:
        messagebox.showerror(
            "Error de conexión",
            f"No fue posible conectar con la base de datos:\n{error}",
        )
        return None

    return conexion


def mostrarPro():
    conexion = conectar()
    if conexion is None:
        return

    cursor = None
    try:
        cursor = conexion.cursor()
        cursor.execute("SELECT * FROM productos")

        tabla.delete(*tabla.get_children())
        for fila in cursor:
            tabla.insert(parent="", index=tk.END, values=fila)
    except mysql.connector.Error as error:
        messagebox.showerror(
            "Error al consultar",
            f"No fue posible mostrar los productos:\n{error}",
        )
    finally:
        if cursor is not None:
            cursor.close()
        conexion.close()


def insertarPro():
    codigo = cajaC.get().strip()
    descripcion = cajaD.get().strip()
    if not codigo or not descripcion:
        messagebox.showwarning(
            "Datos incompletos",
            "Ingresa el código y la descripción del producto.",
        )
        return

    conexion = conectar()
    if conexion is None:
        return

    cursor = None
    try:
        cursor = conexion.cursor()
        cursor.execute(
            "INSERT INTO productos VALUES (%s, %s)",
            (codigo, descripcion),
        )
        conexion.commit()
        cajaC.delete(0, tk.END)
        cajaD.delete(0, tk.END)
        mostrarPro()
    except mysql.connector.Error as error:
        messagebox.showerror(
            "Error al insertar",
            f"No fue posible guardar el producto:\n{error}",
        )
    finally:
        if cursor is not None:
            cursor.close()
        conexion.close()


def buscarPro():
    codigo = cajaC.get().strip()
    if not codigo:
        messagebox.showwarning(
            "Dato faltante",
            "Ingresa el código del producto que deseas buscar.",
        )
        return

    conexion = conectar()
    if conexion is None:
        return

    cursor = None
    try:
        cursor = conexion.cursor()
        cursor.execute(
            "SELECT * FROM productos WHERE pro_codigo_k = %s",
            (codigo,),
        )
        filas = cursor.fetchall()

        tabla.delete(*tabla.get_children())
        for fila in filas:
            tabla.insert(parent="", index=tk.END, values=fila)

        if not filas:
            messagebox.showinfo(
                "Sin resultados",
                "No se encontró un producto con ese código.",
            )
    except mysql.connector.Error as error:
        messagebox.showerror(
            "Error al buscar",
            f"No fue posible buscar el producto:\n{error}",
        )
    finally:
        if cursor is not None:
            cursor.close()
        conexion.close()


def eliminarPro():
    codigo = cajaC.get().strip()
    if not codigo:
        messagebox.showwarning(
            "Dato faltante",
            "Ingresa el código del producto que deseas eliminar.",
        )
        return

    if not messagebox.askyesno(
        "Confirmar eliminación",
        f"¿Deseas eliminar el producto con código {codigo}?",
    ):
        return

    conexion = conectar()
    if conexion is None:
        return

    cursor = None
    try:
        cursor = conexion.cursor()
        cursor.execute(
            "DELETE FROM productos WHERE pro_codigo_k = %s",
            (codigo,),
        )
        conexion.commit()

        if cursor.rowcount == 0:
            messagebox.showinfo(
                "Sin resultados",
                "No se encontró un producto con ese código.",
            )
        else:
            cajaC.delete(0, tk.END)
            cajaD.delete(0, tk.END)
            mostrarPro()
    except mysql.connector.Error as error:
        messagebox.showerror(
            "Error al eliminar",
            f"No fue posible eliminar el producto:\n{error}",
        )
    finally:
        if cursor is not None:
            cursor.close()
        conexion.close()


def crear_interfaz(contenedor):
    global cajaC, cajaD, tabla

    contenedor.config(bg="light gray")
    tk.Label(contenedor, text="Código:").place(x=50, y=20)
    cajaC = tk.Entry(contenedor, width=20)
    cajaC.place(x=120, y=20)

    tk.Label(contenedor, text="Descripción:").place(x=280, y=20)
    cajaD = tk.Entry(contenedor, width=30)
    cajaD.place(x=360, y=20)

    botones = (
        ("Mostrar", mostrarPro),
        ("Insertar", insertarPro),
        ("Buscar", buscarPro),
        ("Eliminar", eliminarPro),
    )
    for indice, (texto, comando) in enumerate(botones):
        tk.Button(
            contenedor,
            text=texto,
            width=12,
            command=comando,
        ).place(x=50 + indice * 130, y=55)

    tabla = ttk.Treeview(
        contenedor,
        columns=("codigo", "descripcion"),
        show="headings",
        height=12,
    )
    tabla.heading("codigo", text="CÓDIGO")
    tabla.heading("descripcion", text="DESCRIPCIÓN")
    tabla.column("codigo", width=120)
    tabla.column("descripcion", width=350)
    tabla.place(x=50, y=100)

    tk.Button(
        contenedor,
        text="Salir",
        width=12,
        command=contenedor.winfo_toplevel().destroy,
    ).place(x=450, y=420)


def mostrar_pantalla(nombre):
    for widget in contenido.winfo_children():
        widget.destroy()

    pantallas = {
        "Productos": crear_interfaz,
        "Existencias": existencias.crear_interfaz,
        "Movimientos": MOVIMIENTOS.crear_interfaz,
    }
    pantallas[nombre](contenido)


def main():
    global contenido

    ventana = tk.Tk()
    ventana.title("SISTEMA DE INVENTARIO")
    ventana.geometry("1100x620")
    ventana.config(bg="light gray")

    navegacion = tk.Frame(ventana, bg="light gray")
    navegacion.pack(fill=tk.X, padx=10, pady=8)

    for nombre in ("Productos", "Existencias", "Movimientos"):
        tk.Button(
            navegacion,
            text=nombre,
            width=18,
            command=lambda pantalla=nombre: mostrar_pantalla(pantalla),
        ).pack(side=tk.LEFT, padx=5)

    contenido = tk.Frame(ventana, bg="light gray")
    contenido.pack(fill=tk.BOTH, expand=True)
    mostrar_pantalla("Productos")

    ventana.mainloop()


if __name__ == "__main__":
    main()
